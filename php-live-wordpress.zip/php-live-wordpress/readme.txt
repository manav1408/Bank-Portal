=== PHP Live! ===
Contributors: osicodesinc
Tags: live chat, live support, live chat software, live support software, online support, php live, chat addon, chat, chat button, live help, livechat, php live support, chat plugin, widget
Stable tag: 2.0
Requires at least: 2.7
Tested up to: 4.3.1

Chat with your website visitors.

== Description ==

This plugin does not include a free live chat account.  An existing trial account, a Download client account or an On Demand client account is required.

http://www.phplivesupport.com/trial.php

**About PHP Live!**

PHP Live! enables live chat communication with your website visitors.  100% web browser based.  Simply launch a web browser and provide live chat support!  PHP and MySQL powered live chat system.

***Unlimited Departments***

Assign an operator to unlimited number of departments.  Some examples of departments you can create are "Customer Support", "Sales", "General Inquiries" and more.

***Real-time Visitor Traffic Monitor with GeoIP***

View your website traffic in real-time.  GeoIP integration, visitor pageviews, refer URLs and automatic chat invites provide the tools you need for an helpful and streamlined visitor chat experience.



== Installation ==

1. Upload the 'php-live-wordpress' directory to your Wordpress plugins directory ('/wp-content/plugins/')
2. Activate the plugin in the "Plugins" admin panel using the "Activate" link.
3. Click the newly created 'PHP Live!' menu on the left side of the admin panel.
4. Proceed with the steps detailed on the PHP Live! plugins page.


== Screenshots ==

1. Chat window themes.
2. Operator incoming chat request.
3. Real-time visitor traffic monitor.


== Changelog ==

= 2.0 =
* Updated various texts, js lib and interface

= 1.9 =
* Updated various texts

= 1.8 =
* Updated various texts and links

= 1.7 =
* Updated various texts and links

= 1.6 =
* Updated various texts and links

= 1.5 =
* Simplified the plugin and navigation

= 1.4 =
* Updated various texts and links

= 1.3 =
* Fixed a possible error during verifying the PHP Live! URL

= 1.2 =
* Added additional error checking and reporting

= 1.1 =
* Added Server Info tab to check for various server settings

= 1.0 =
* Stable version 1.0

= 0.9.3 =
* Updated various texts

= 0.9.2 =
* Updated various texts

= 0.9.1 =
* Updated readme and file paths

= 0.9 =
* Beta release.

