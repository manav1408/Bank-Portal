<?php
$author = "Nemako";
$website = "http://www.nemako.net";
$screenshot = "http://img111.imageshack.us/img111/1681/blune1xe.png";
?>