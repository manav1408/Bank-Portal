<?php

require_once dirname(__FILE__)."/../src/phpfreechat.class.php";
require_once "demo3_config.php";
$chat = new phpFreeChat( $params );

?>